// 23-client DATA MOVER variant of the EES331 six-peer/PS7 top.
// Original cache-based top remains in face_soc_ees331_top.sv for comparison.
module face_soc_ees331_mover_top #(
 parameter integer LOCAL_BYTES=32768,
 parameter bit POOL23=1,
 parameter string IMEM_INIT_FILE="firmware/ees331_cpu/program.mem"
) (
`ifdef EES331_EXTERNAL_PS
 input wire FCLK_CLK0, FCLK_RESET0_N,
 output wire M_AXI_GP0_ACLK, S_AXI_HP0_ACLK,
 input wire [31:0] M_AXI_GP0_AWADDR,
 input wire [31:0] M_AXI_GP0_ARADDR,
 input wire [31:0] M_AXI_GP0_WDATA,
 output wire [31:0] M_AXI_GP0_RDATA,
 input wire [11:0] M_AXI_GP0_AWID,
 input wire [11:0] M_AXI_GP0_ARID,
 input wire [11:0] M_AXI_GP0_WID,
 input wire [3:0] M_AXI_GP0_AWLEN,
 input wire [3:0] M_AXI_GP0_ARLEN,
 input wire [2:0] M_AXI_GP0_AWSIZE,
 input wire [2:0] M_AXI_GP0_ARSIZE,
 input wire [1:0] M_AXI_GP0_AWBURST,
 input wire [1:0] M_AXI_GP0_ARBURST,
 input wire [1:0] M_AXI_GP0_AWLOCK,
 input wire [1:0] M_AXI_GP0_ARLOCK,
 input wire [3:0] M_AXI_GP0_AWCACHE,
 input wire [3:0] M_AXI_GP0_ARCACHE,
 input wire [2:0] M_AXI_GP0_AWPROT,
 input wire [2:0] M_AXI_GP0_ARPROT,
 input wire [3:0] M_AXI_GP0_AWQOS,
 input wire [3:0] M_AXI_GP0_ARQOS,
 input wire [3:0] M_AXI_GP0_WSTRB,
 input wire M_AXI_GP0_AWVALID,
 input wire M_AXI_GP0_WVALID,
 input wire M_AXI_GP0_WLAST,
 input wire M_AXI_GP0_BREADY,
 input wire M_AXI_GP0_ARVALID,
 input wire M_AXI_GP0_RREADY,
 output wire [11:0] M_AXI_GP0_BID,
 output wire [11:0] M_AXI_GP0_RID,
 output wire [1:0] M_AXI_GP0_BRESP,
 output wire [1:0] M_AXI_GP0_RRESP,
 output wire M_AXI_GP0_AWREADY,
 output wire M_AXI_GP0_WREADY,
 output wire M_AXI_GP0_BVALID,
 output wire M_AXI_GP0_ARREADY,
 output wire M_AXI_GP0_RVALID,
 output wire M_AXI_GP0_RLAST,
 output wire [31:0] S_AXI_HP0_AWADDR,
 output wire [31:0] S_AXI_HP0_ARADDR,
 output wire [63:0] S_AXI_HP0_WDATA,
 input wire [63:0] S_AXI_HP0_RDATA,
 output wire [5:0] S_AXI_HP0_AWID,
 output wire [5:0] S_AXI_HP0_ARID,
 output wire [5:0] S_AXI_HP0_WID,
 output wire [3:0] S_AXI_HP0_AWLEN,
 output wire [3:0] S_AXI_HP0_ARLEN,
 output wire [2:0] S_AXI_HP0_AWSIZE,
 output wire [2:0] S_AXI_HP0_ARSIZE,
 output wire [1:0] S_AXI_HP0_AWBURST,
 output wire [1:0] S_AXI_HP0_ARBURST,
 output wire [1:0] S_AXI_HP0_AWLOCK,
 output wire [1:0] S_AXI_HP0_ARLOCK,
 output wire [3:0] S_AXI_HP0_AWCACHE,
 output wire [3:0] S_AXI_HP0_ARCACHE,
 output wire [2:0] S_AXI_HP0_AWPROT,
 output wire [2:0] S_AXI_HP0_ARPROT,
 output wire [3:0] S_AXI_HP0_AWQOS,
 output wire [3:0] S_AXI_HP0_ARQOS,
 output wire [7:0] S_AXI_HP0_WSTRB,
 output wire S_AXI_HP0_AWVALID,
 output wire S_AXI_HP0_WVALID,
 output wire S_AXI_HP0_WLAST,
 output wire S_AXI_HP0_BREADY,
 output wire S_AXI_HP0_ARVALID,
 output wire S_AXI_HP0_RREADY,
 input wire [5:0] S_AXI_HP0_BID,
 input wire [5:0] S_AXI_HP0_RID,
 input wire [1:0] S_AXI_HP0_BRESP,
 input wire [1:0] S_AXI_HP0_RRESP,
 input wire S_AXI_HP0_AWREADY,
 input wire S_AXI_HP0_WREADY,
 input wire S_AXI_HP0_BVALID,
 input wire S_AXI_HP0_ARREADY,
 input wire S_AXI_HP0_RVALID,
 input wire S_AXI_HP0_RLAST
`else
 inout wire [14:0] DDR_Addr,
 inout wire [2:0] DDR_BankAddr,
 inout wire [3:0] DDR_DM,
 inout wire [31:0] DDR_DQ,
 inout wire [3:0] DDR_DQS,
 inout wire [3:0] DDR_DQS_n,
 inout wire DDR_Clk,
 inout wire DDR_Clk_n,
 inout wire DDR_CKE,
 inout wire DDR_CS_n,
 inout wire DDR_RAS_n,
 inout wire DDR_CAS_n,
 inout wire DDR_WEB,
 inout wire DDR_ODT,
 inout wire DDR_DRSTB,
 inout wire DDR_VRN,
 inout wire DDR_VRP,
 inout wire [53:0] FIXED_IO_MIO,
 inout wire FIXED_IO_PS_CLK,
 inout wire FIXED_IO_PS_PORB,
 inout wire FIXED_IO_PS_SRSTB
`endif
);
 wire clk, rst_n;
 wire sys_clk, rst_n_in;
 localparam integer CNN_K3=POOL23 ? 4 : 2;
 localparam integer CNN_K1=POOL23 ? 12 : 4;
 localparam integer CNN_POST=POOL23 ? 4 : 1;
 localparam integer CNN_CLIENTS=CNN_K3+CNN_K1+CNN_POST+3;
 // I: CPU取指
 wire [31:0] imem_addr;
 wire [31:0] imem_rdata;
 wire imem_re;
 // D: CPU本地数据口
 wire [31:0] dmem_addr;
 wire [31:0] dmem_wdata;
 wire [31:0] dmem_rdata;
 wire dmem_re;
 wire dmem_we;
 wire [3:0] dmem_wstrb;
 // M0: CPU控制/邮箱口
 wire [31:0] mmio_addr;
 wire [31:0] mmio_wdata;
 wire [31:0] mmio_rdata;
 wire mmio_re;
 wire mmio_we;
 wire mmio_ready;
 // M1: CNN寄存器封装
 wire [31:0] cnn_mmio_addr;
 wire [31:0] cnn_mmio_wdata;
 wire [31:0] cnn_mmio_rdata;
 wire cnn_mmio_re;
 wire cnn_mmio_we;
 wire cnn_mmio_ready;
 // C: 10路新CNN访存
 wire [CNN_CLIENTS*32-1:0] cnn_addr;
 wire [CNN_CLIENTS*32-1:0] cnn_wdata;
 wire [CNN_CLIENTS*32-1:0] cnn_rdata;
 wire [CNN_CLIENTS-1:0] cnn_valid;
 wire [CNN_CLIENTS-1:0] cnn_write;
 wire [CNN_CLIENTS-1:0] cnn_byte;
 wire cnn_cancel;
 wire [CNN_CLIENTS-1:0] cnn_ready;
 wire [CNN_CLIENTS-1:0] cnn_response;
 wire cnn_mem_fault;
 // F: cache维护寄存器
 wire [31:0] cache_csr_addr;
 wire [31:0] cache_csr_wdata;
 wire [31:0] cache_csr_rdata;
 wire cache_csr_re;
 wire cache_csr_we;
 wire cache_csr_ready;
`ifndef EES331_EXTERNAL_PS
 wire FCLK_CLK0, FCLK_RESET0_N;
 wire M_AXI_GP0_ACLK, S_AXI_HP0_ACLK;
 wire [31:0] M_AXI_GP0_AWADDR;
 wire [31:0] M_AXI_GP0_ARADDR;
 wire [31:0] M_AXI_GP0_WDATA;
 wire [31:0] M_AXI_GP0_RDATA;
 wire [11:0] M_AXI_GP0_AWID;
 wire [11:0] M_AXI_GP0_ARID;
 wire [11:0] M_AXI_GP0_WID;
 wire [3:0] M_AXI_GP0_AWLEN;
 wire [3:0] M_AXI_GP0_ARLEN;
 wire [2:0] M_AXI_GP0_AWSIZE;
 wire [2:0] M_AXI_GP0_ARSIZE;
 wire [1:0] M_AXI_GP0_AWBURST;
 wire [1:0] M_AXI_GP0_ARBURST;
 wire [1:0] M_AXI_GP0_AWLOCK;
 wire [1:0] M_AXI_GP0_ARLOCK;
 wire [3:0] M_AXI_GP0_AWCACHE;
 wire [3:0] M_AXI_GP0_ARCACHE;
 wire [2:0] M_AXI_GP0_AWPROT;
 wire [2:0] M_AXI_GP0_ARPROT;
 wire [3:0] M_AXI_GP0_AWQOS;
 wire [3:0] M_AXI_GP0_ARQOS;
 wire [3:0] M_AXI_GP0_WSTRB;
 wire M_AXI_GP0_AWVALID;
 wire M_AXI_GP0_WVALID;
 wire M_AXI_GP0_WLAST;
 wire M_AXI_GP0_BREADY;
 wire M_AXI_GP0_ARVALID;
 wire M_AXI_GP0_RREADY;
 wire [11:0] M_AXI_GP0_BID;
 wire [11:0] M_AXI_GP0_RID;
 wire [1:0] M_AXI_GP0_BRESP;
 wire [1:0] M_AXI_GP0_RRESP;
 wire M_AXI_GP0_AWREADY;
 wire M_AXI_GP0_WREADY;
 wire M_AXI_GP0_BVALID;
 wire M_AXI_GP0_ARREADY;
 wire M_AXI_GP0_RVALID;
 wire M_AXI_GP0_RLAST;
 wire [31:0] S_AXI_HP0_AWADDR;
 wire [31:0] S_AXI_HP0_ARADDR;
 wire [63:0] S_AXI_HP0_WDATA;
 wire [63:0] S_AXI_HP0_RDATA;
 wire [5:0] S_AXI_HP0_AWID;
 wire [5:0] S_AXI_HP0_ARID;
 wire [5:0] S_AXI_HP0_WID;
 wire [3:0] S_AXI_HP0_AWLEN;
 wire [3:0] S_AXI_HP0_ARLEN;
 wire [2:0] S_AXI_HP0_AWSIZE;
 wire [2:0] S_AXI_HP0_ARSIZE;
 wire [1:0] S_AXI_HP0_AWBURST;
 wire [1:0] S_AXI_HP0_ARBURST;
 wire [1:0] S_AXI_HP0_AWLOCK;
 wire [1:0] S_AXI_HP0_ARLOCK;
 wire [3:0] S_AXI_HP0_AWCACHE;
 wire [3:0] S_AXI_HP0_ARCACHE;
 wire [2:0] S_AXI_HP0_AWPROT;
 wire [2:0] S_AXI_HP0_ARPROT;
 wire [3:0] S_AXI_HP0_AWQOS;
 wire [3:0] S_AXI_HP0_ARQOS;
 wire [7:0] S_AXI_HP0_WSTRB;
 wire S_AXI_HP0_AWVALID;
 wire S_AXI_HP0_WVALID;
 wire S_AXI_HP0_WLAST;
 wire S_AXI_HP0_BREADY;
 wire S_AXI_HP0_ARVALID;
 wire S_AXI_HP0_RREADY;
 wire [5:0] S_AXI_HP0_BID;
 wire [5:0] S_AXI_HP0_RID;
 wire [1:0] S_AXI_HP0_BRESP;
 wire [1:0] S_AXI_HP0_RRESP;
 wire S_AXI_HP0_AWREADY;
 wire S_AXI_HP0_WREADY;
 wire S_AXI_HP0_BVALID;
 wire S_AXI_HP0_ARREADY;
 wire S_AXI_HP0_RVALID;
 wire S_AXI_HP0_RLAST;
`endif
 assign sys_clk=FCLK_CLK0;
 assign rst_n_in=FCLK_RESET0_N;
 assign M_AXI_GP0_ACLK=clk;
 assign S_AXI_HP0_ACLK=clk;
 clock_unit u_clock_unit (.sys_clk(sys_clk),.rst_n_in(rst_n_in),.clk(clk),.rst_n(rst_n));
 cpu_core #(.SRAM_BASE(32'h0),.SRAM_SIZE(32'h4000),.CNN_MMIO_BASE(32'h40000000)) u_cpu_core (
  .clk(clk),
  .rst_n(rst_n),
  .imem_addr(imem_addr),
  .imem_rdata(imem_rdata),
  .imem_re(imem_re),
  .dmem_addr(dmem_addr),
  .dmem_wdata(dmem_wdata),
  .dmem_rdata(dmem_rdata),
  .dmem_re(dmem_re),
  .dmem_we(dmem_we),
  .dmem_wstrb(dmem_wstrb),
  .mmio_addr(mmio_addr),
  .mmio_wdata(mmio_wdata),
  .mmio_rdata(mmio_rdata),
  .mmio_re(mmio_re),
  .mmio_we(mmio_we),
  .mmio_ready(mmio_ready)
 );
 imem_rom #(.IMEM_SIZE(32'h2000),.INIT_FILE(IMEM_INIT_FILE)) u_imem (
  .clk(clk),
  .rst_n(rst_n),
  .imem_addr(imem_addr),
  .imem_rdata(imem_rdata),
  .imem_re(imem_re)
 );
 cnn_ees331 #(.K3_UNITS(CNN_K3),.K1_UNITS(CNN_K1),.POST_UNITS(CNN_POST),.LATEST_OPERATORS(POOL23)) u_cnn (
  .clk(clk),
  .rst_n(rst_n),
  .cnn_mmio_addr(cnn_mmio_addr),
  .cnn_mmio_wdata(cnn_mmio_wdata),
  .cnn_mmio_rdata(cnn_mmio_rdata),
  .cnn_mmio_re(cnn_mmio_re),
  .cnn_mmio_we(cnn_mmio_we),
  .cnn_mmio_ready(cnn_mmio_ready),
  .cnn_addr(cnn_addr),
  .cnn_wdata(cnn_wdata),
  .cnn_rdata(cnn_rdata),
  .cnn_valid(cnn_valid),
  .cnn_write(cnn_write),
  .cnn_byte(cnn_byte),
  .cnn_cancel(cnn_cancel),
  .cnn_ready(cnn_ready),
  .cnn_response(cnn_response),
  .cnn_mem_fault(cnn_mem_fault)
 );
 datasram_mover_subsystem #(.CLIENTS(CNN_CLIENTS),.LOCAL_BYTES(LOCAL_BYTES),.CPU_RAM_BYTES(16384),.LOGICAL_BYTES(POOL23 ? 32'h04000000 : 32'h01000000)) u_datasram (
  .clk(clk),
  .rst_n(rst_n),
  .dmem_addr(dmem_addr),
  .dmem_wdata(dmem_wdata),
  .dmem_rdata(dmem_rdata),
  .dmem_re(dmem_re),
  .dmem_we(dmem_we),
  .dmem_wstrb(dmem_wstrb),
  .cnn_addr(cnn_addr),
  .cnn_wdata(cnn_wdata),
  .cnn_rdata(cnn_rdata),
  .cnn_valid(cnn_valid),
  .cnn_write(cnn_write),
  .cnn_byte(cnn_byte),
  .cnn_cancel(cnn_cancel),
  .cnn_ready(cnn_ready),
  .cnn_response(cnn_response),
  .cnn_mem_fault(cnn_mem_fault),
  .cache_csr_addr(cache_csr_addr),
  .cache_csr_wdata(cache_csr_wdata),
  .cache_csr_rdata(cache_csr_rdata),
  .cache_csr_re(cache_csr_re),
  .cache_csr_we(cache_csr_we),
  .cache_csr_ready(cache_csr_ready),
  .S_AXI_HP0_AWADDR(S_AXI_HP0_AWADDR),
  .S_AXI_HP0_ARADDR(S_AXI_HP0_ARADDR),
  .S_AXI_HP0_WDATA(S_AXI_HP0_WDATA),
  .S_AXI_HP0_RDATA(S_AXI_HP0_RDATA),
  .S_AXI_HP0_AWID(S_AXI_HP0_AWID),
  .S_AXI_HP0_ARID(S_AXI_HP0_ARID),
  .S_AXI_HP0_WID(S_AXI_HP0_WID),
  .S_AXI_HP0_AWLEN(S_AXI_HP0_AWLEN),
  .S_AXI_HP0_ARLEN(S_AXI_HP0_ARLEN),
  .S_AXI_HP0_AWSIZE(S_AXI_HP0_AWSIZE),
  .S_AXI_HP0_ARSIZE(S_AXI_HP0_ARSIZE),
  .S_AXI_HP0_AWBURST(S_AXI_HP0_AWBURST),
  .S_AXI_HP0_ARBURST(S_AXI_HP0_ARBURST),
  .S_AXI_HP0_AWLOCK(S_AXI_HP0_AWLOCK),
  .S_AXI_HP0_ARLOCK(S_AXI_HP0_ARLOCK),
  .S_AXI_HP0_AWCACHE(S_AXI_HP0_AWCACHE),
  .S_AXI_HP0_ARCACHE(S_AXI_HP0_ARCACHE),
  .S_AXI_HP0_AWPROT(S_AXI_HP0_AWPROT),
  .S_AXI_HP0_ARPROT(S_AXI_HP0_ARPROT),
  .S_AXI_HP0_AWQOS(S_AXI_HP0_AWQOS),
  .S_AXI_HP0_ARQOS(S_AXI_HP0_ARQOS),
  .S_AXI_HP0_WSTRB(S_AXI_HP0_WSTRB),
  .S_AXI_HP0_AWVALID(S_AXI_HP0_AWVALID),
  .S_AXI_HP0_WVALID(S_AXI_HP0_WVALID),
  .S_AXI_HP0_WLAST(S_AXI_HP0_WLAST),
  .S_AXI_HP0_BREADY(S_AXI_HP0_BREADY),
  .S_AXI_HP0_ARVALID(S_AXI_HP0_ARVALID),
  .S_AXI_HP0_RREADY(S_AXI_HP0_RREADY),
  .S_AXI_HP0_BID(S_AXI_HP0_BID),
  .S_AXI_HP0_RID(S_AXI_HP0_RID),
  .S_AXI_HP0_BRESP(S_AXI_HP0_BRESP),
  .S_AXI_HP0_RRESP(S_AXI_HP0_RRESP),
  .S_AXI_HP0_AWREADY(S_AXI_HP0_AWREADY),
  .S_AXI_HP0_WREADY(S_AXI_HP0_WREADY),
  .S_AXI_HP0_BVALID(S_AXI_HP0_BVALID),
  .S_AXI_HP0_ARREADY(S_AXI_HP0_ARREADY),
  .S_AXI_HP0_RVALID(S_AXI_HP0_RVALID),
  .S_AXI_HP0_RLAST(S_AXI_HP0_RLAST)
 );
 image_control_bridge  u_image_bridge (
  .clk(clk),
  .rst_n(rst_n),
  .mmio_addr(mmio_addr),
  .mmio_wdata(mmio_wdata),
  .mmio_rdata(mmio_rdata),
  .mmio_re(mmio_re),
  .mmio_we(mmio_we),
  .mmio_ready(mmio_ready),
  .cnn_mmio_addr(cnn_mmio_addr),
  .cnn_mmio_wdata(cnn_mmio_wdata),
  .cnn_mmio_rdata(cnn_mmio_rdata),
  .cnn_mmio_re(cnn_mmio_re),
  .cnn_mmio_we(cnn_mmio_we),
  .cnn_mmio_ready(cnn_mmio_ready),
  .cache_csr_addr(cache_csr_addr),
  .cache_csr_wdata(cache_csr_wdata),
  .cache_csr_rdata(cache_csr_rdata),
  .cache_csr_re(cache_csr_re),
  .cache_csr_we(cache_csr_we),
  .cache_csr_ready(cache_csr_ready),
  .M_AXI_GP0_AWADDR(M_AXI_GP0_AWADDR),
  .M_AXI_GP0_ARADDR(M_AXI_GP0_ARADDR),
  .M_AXI_GP0_WDATA(M_AXI_GP0_WDATA),
  .M_AXI_GP0_RDATA(M_AXI_GP0_RDATA),
  .M_AXI_GP0_AWID(M_AXI_GP0_AWID),
  .M_AXI_GP0_ARID(M_AXI_GP0_ARID),
  .M_AXI_GP0_WID(M_AXI_GP0_WID),
  .M_AXI_GP0_AWLEN(M_AXI_GP0_AWLEN),
  .M_AXI_GP0_ARLEN(M_AXI_GP0_ARLEN),
  .M_AXI_GP0_AWSIZE(M_AXI_GP0_AWSIZE),
  .M_AXI_GP0_ARSIZE(M_AXI_GP0_ARSIZE),
  .M_AXI_GP0_AWBURST(M_AXI_GP0_AWBURST),
  .M_AXI_GP0_ARBURST(M_AXI_GP0_ARBURST),
  .M_AXI_GP0_AWLOCK(M_AXI_GP0_AWLOCK),
  .M_AXI_GP0_ARLOCK(M_AXI_GP0_ARLOCK),
  .M_AXI_GP0_AWCACHE(M_AXI_GP0_AWCACHE),
  .M_AXI_GP0_ARCACHE(M_AXI_GP0_ARCACHE),
  .M_AXI_GP0_AWPROT(M_AXI_GP0_AWPROT),
  .M_AXI_GP0_ARPROT(M_AXI_GP0_ARPROT),
  .M_AXI_GP0_AWQOS(M_AXI_GP0_AWQOS),
  .M_AXI_GP0_ARQOS(M_AXI_GP0_ARQOS),
  .M_AXI_GP0_WSTRB(M_AXI_GP0_WSTRB),
  .M_AXI_GP0_AWVALID(M_AXI_GP0_AWVALID),
  .M_AXI_GP0_WVALID(M_AXI_GP0_WVALID),
  .M_AXI_GP0_WLAST(M_AXI_GP0_WLAST),
  .M_AXI_GP0_BREADY(M_AXI_GP0_BREADY),
  .M_AXI_GP0_ARVALID(M_AXI_GP0_ARVALID),
  .M_AXI_GP0_RREADY(M_AXI_GP0_RREADY),
  .M_AXI_GP0_BID(M_AXI_GP0_BID),
  .M_AXI_GP0_RID(M_AXI_GP0_RID),
  .M_AXI_GP0_BRESP(M_AXI_GP0_BRESP),
  .M_AXI_GP0_RRESP(M_AXI_GP0_RRESP),
  .M_AXI_GP0_AWREADY(M_AXI_GP0_AWREADY),
  .M_AXI_GP0_WREADY(M_AXI_GP0_WREADY),
  .M_AXI_GP0_BVALID(M_AXI_GP0_BVALID),
  .M_AXI_GP0_ARREADY(M_AXI_GP0_ARREADY),
  .M_AXI_GP0_RVALID(M_AXI_GP0_RVALID),
  .M_AXI_GP0_RLAST(M_AXI_GP0_RLAST)
 );
`ifndef EES331_EXTERNAL_PS
 // PS UART1 TX/RX use existing MIO48/49 to J3, not new PL wires.
 // HP issue capability defaults: normal buffering, no forced single issue.
 ees331_ps_wrapper u_ps (
  .DDR_Addr(DDR_Addr),
  .DDR_BankAddr(DDR_BankAddr),
  .DDR_DM(DDR_DM),
  .DDR_DQ(DDR_DQ),
  .DDR_DQS(DDR_DQS),
  .DDR_DQS_n(DDR_DQS_n),
  .DDR_Clk(DDR_Clk),
  .DDR_Clk_n(DDR_Clk_n),
  .DDR_CKE(DDR_CKE),
  .DDR_CS_n(DDR_CS_n),
  .DDR_RAS_n(DDR_RAS_n),
  .DDR_CAS_n(DDR_CAS_n),
  .DDR_WEB(DDR_WEB),
  .DDR_ODT(DDR_ODT),
  .DDR_DRSTB(DDR_DRSTB),
  .DDR_VRN(DDR_VRN),
  .DDR_VRP(DDR_VRP),
  .FIXED_IO_MIO(FIXED_IO_MIO),
  .FIXED_IO_PS_CLK(FIXED_IO_PS_CLK),
  .FIXED_IO_PS_PORB(FIXED_IO_PS_PORB),
  .FIXED_IO_PS_SRSTB(FIXED_IO_PS_SRSTB),
  .FCLK_CLK0(FCLK_CLK0),
  .FCLK_RESET0_N(FCLK_RESET0_N),
  .M_AXI_GP0_ACLK(M_AXI_GP0_ACLK),
  .S_AXI_HP0_ACLK(S_AXI_HP0_ACLK),
  .M_AXI_GP0_AWADDR(M_AXI_GP0_AWADDR),
  .M_AXI_GP0_ARADDR(M_AXI_GP0_ARADDR),
  .M_AXI_GP0_WDATA(M_AXI_GP0_WDATA),
  .M_AXI_GP0_RDATA(M_AXI_GP0_RDATA),
  .M_AXI_GP0_AWID(M_AXI_GP0_AWID),
  .M_AXI_GP0_ARID(M_AXI_GP0_ARID),
  .M_AXI_GP0_WID(M_AXI_GP0_WID),
  .M_AXI_GP0_AWLEN(M_AXI_GP0_AWLEN),
  .M_AXI_GP0_ARLEN(M_AXI_GP0_ARLEN),
  .M_AXI_GP0_AWSIZE(M_AXI_GP0_AWSIZE),
  .M_AXI_GP0_ARSIZE(M_AXI_GP0_ARSIZE),
  .M_AXI_GP0_AWBURST(M_AXI_GP0_AWBURST),
  .M_AXI_GP0_ARBURST(M_AXI_GP0_ARBURST),
  .M_AXI_GP0_AWLOCK(M_AXI_GP0_AWLOCK),
  .M_AXI_GP0_ARLOCK(M_AXI_GP0_ARLOCK),
  .M_AXI_GP0_AWCACHE(M_AXI_GP0_AWCACHE),
  .M_AXI_GP0_ARCACHE(M_AXI_GP0_ARCACHE),
  .M_AXI_GP0_AWPROT(M_AXI_GP0_AWPROT),
  .M_AXI_GP0_ARPROT(M_AXI_GP0_ARPROT),
  .M_AXI_GP0_AWQOS(M_AXI_GP0_AWQOS),
  .M_AXI_GP0_ARQOS(M_AXI_GP0_ARQOS),
  .M_AXI_GP0_WSTRB(M_AXI_GP0_WSTRB),
  .M_AXI_GP0_AWVALID(M_AXI_GP0_AWVALID),
  .M_AXI_GP0_WVALID(M_AXI_GP0_WVALID),
  .M_AXI_GP0_WLAST(M_AXI_GP0_WLAST),
  .M_AXI_GP0_BREADY(M_AXI_GP0_BREADY),
  .M_AXI_GP0_ARVALID(M_AXI_GP0_ARVALID),
  .M_AXI_GP0_RREADY(M_AXI_GP0_RREADY),
  .M_AXI_GP0_BID(M_AXI_GP0_BID),
  .M_AXI_GP0_RID(M_AXI_GP0_RID),
  .M_AXI_GP0_BRESP(M_AXI_GP0_BRESP),
  .M_AXI_GP0_RRESP(M_AXI_GP0_RRESP),
  .M_AXI_GP0_AWREADY(M_AXI_GP0_AWREADY),
  .M_AXI_GP0_WREADY(M_AXI_GP0_WREADY),
  .M_AXI_GP0_BVALID(M_AXI_GP0_BVALID),
  .M_AXI_GP0_ARREADY(M_AXI_GP0_ARREADY),
  .M_AXI_GP0_RVALID(M_AXI_GP0_RVALID),
  .M_AXI_GP0_RLAST(M_AXI_GP0_RLAST),
  .S_AXI_HP0_AWADDR(S_AXI_HP0_AWADDR),
  .S_AXI_HP0_ARADDR(S_AXI_HP0_ARADDR),
  .S_AXI_HP0_WDATA(S_AXI_HP0_WDATA),
  .S_AXI_HP0_RDATA(S_AXI_HP0_RDATA),
  .S_AXI_HP0_AWID(S_AXI_HP0_AWID),
  .S_AXI_HP0_ARID(S_AXI_HP0_ARID),
  .S_AXI_HP0_WID(S_AXI_HP0_WID),
  .S_AXI_HP0_AWLEN(S_AXI_HP0_AWLEN),
  .S_AXI_HP0_ARLEN(S_AXI_HP0_ARLEN),
  .S_AXI_HP0_AWSIZE(S_AXI_HP0_AWSIZE),
  .S_AXI_HP0_ARSIZE(S_AXI_HP0_ARSIZE),
  .S_AXI_HP0_AWBURST(S_AXI_HP0_AWBURST),
  .S_AXI_HP0_ARBURST(S_AXI_HP0_ARBURST),
  .S_AXI_HP0_AWLOCK(S_AXI_HP0_AWLOCK),
  .S_AXI_HP0_ARLOCK(S_AXI_HP0_ARLOCK),
  .S_AXI_HP0_AWCACHE(S_AXI_HP0_AWCACHE),
  .S_AXI_HP0_ARCACHE(S_AXI_HP0_ARCACHE),
  .S_AXI_HP0_AWPROT(S_AXI_HP0_AWPROT),
  .S_AXI_HP0_ARPROT(S_AXI_HP0_ARPROT),
  .S_AXI_HP0_AWQOS(S_AXI_HP0_AWQOS),
  .S_AXI_HP0_ARQOS(S_AXI_HP0_ARQOS),
  .S_AXI_HP0_WSTRB(S_AXI_HP0_WSTRB),
  .S_AXI_HP0_AWVALID(S_AXI_HP0_AWVALID),
  .S_AXI_HP0_WVALID(S_AXI_HP0_WVALID),
  .S_AXI_HP0_WLAST(S_AXI_HP0_WLAST),
  .S_AXI_HP0_BREADY(S_AXI_HP0_BREADY),
  .S_AXI_HP0_ARVALID(S_AXI_HP0_ARVALID),
  .S_AXI_HP0_RREADY(S_AXI_HP0_RREADY),
  .S_AXI_HP0_BID(S_AXI_HP0_BID),
  .S_AXI_HP0_RID(S_AXI_HP0_RID),
  .S_AXI_HP0_BRESP(S_AXI_HP0_BRESP),
  .S_AXI_HP0_RRESP(S_AXI_HP0_RRESP),
  .S_AXI_HP0_AWREADY(S_AXI_HP0_AWREADY),
  .S_AXI_HP0_WREADY(S_AXI_HP0_WREADY),
  .S_AXI_HP0_BVALID(S_AXI_HP0_BVALID),
  .S_AXI_HP0_ARREADY(S_AXI_HP0_ARREADY),
  .S_AXI_HP0_RVALID(S_AXI_HP0_RVALID),
  .S_AXI_HP0_RLAST(S_AXI_HP0_RLAST),
  .S_AXI_HP0_RDISSUECAP1_EN(1'b0),
  .S_AXI_HP0_WRISSUECAP1_EN(1'b0),
  .S_AXI_HP0_RCOUNT(),.S_AXI_HP0_WCOUNT(),.S_AXI_HP0_RACOUNT(),.S_AXI_HP0_WACOUNT()
 );
`endif
endmodule
