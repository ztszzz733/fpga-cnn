# CPU_CONTROL P1 对齐验证报告

交付核对另已通过：[alignment_checks.json](../build/runs/20260914_155026_886660_all_seed1/alignment_checks.json)。48 端口表与 RTL 的方向/位宽一致；7 文件生产清单与回归使用的生产源顺序一致，单独编译并展开 cpu_control 成功（[独立编译日志](../build/runs/20260914_155026_886660_all_seed1/production_only/compile.log)）；44 个受保护原始输入/RTL/TB/归档文件哈希未改变，P1 归档与桌面源文件逐字节一致。

2026-09-14：**Control v1.0 / C1 本方正式确认后的完整回归 PASS：1,244 场景、30,463 检查、0 失败。** 生产 Control 和 test-only stub 均未修改，重新运行验证交付基准。真实 Datapath/CNN 未提供，真实直连未运行。

命令：`python scripts/run_tests.py --test all --seed 1 --random-cases 1000 --waves --plot`。使用 Vivado XSim 2026.1，编译、展开、仿真和绘图成功，命令退出 0；编译/展开日志未发现 WARNING/ERROR。

| 验证范围 | 本次结果 |
|---|---|
| RV32I 与 uses_rs1/uses_rs2 | 55 条定向译码向量（含 37 条支持指令）+ 1,000 条随机合法编码变体 |
| 前递 | 16 个定向状态 + 128 个约束随机状态；MEM 非 Load 优先 WB、valid/源使用/x0 门控、MEM Load 遮挡旧 WB |
| load-use | 16 个定向状态，7 次真依赖命中；程序 LW→ADD 和 LW→SW 各暂停一次 |
| 分支/跳转 | 六类分支各跳/不跳，JAL/JALR、前递比较、JALR bit0 清零、PC+4 链接与错路冲刷 |
| 安全行为 | 无效级、副作用、运行中同步复位、flush 优先、仲裁器 reset > redirect > stall、非法/FENCE/ECALL/EBREAK 连续执行 |
| 接口样例 | 真实 Control 与 test-only stub 的 48 端口显式命名连接；不等于生产 Datapath 已接入 |

本次证据：[result.json](../build/runs/20260914_155026_886660_all_seed1/result.json)、[编译日志](../build/runs/20260914_155026_886660_all_seed1/compile.log)、[仿真日志](../build/runs/20260914_155026_886660_all_seed1/simulation.log)、[TB 汇总](../build/runs/20260914_155026_886660_all_seed1/tb_summary.json)、[完整 VCD](../build/runs/20260914_155026_886660_all_seed1/waves/cpu_control.vcd)。源文件哈希见 [verification_manifest.json](verification_manifest.json)。

四张本次新生成的图均已打开检查，标签和总线值可读，暂停/前递/冲刷变化与检查结果相符；未用历史图片替代。

| 场景 | 本次图片 |
|---|---|
| decode | [PNG](../build/runs/20260914_155026_886660_all_seed1/figures/decode.png) |
| forwarding | [PNG](../build/runs/20260914_155026_886660_all_seed1/figures/forwarding.png) |
| load_use | [PNG](../build/runs/20260914_155026_886660_all_seed1/figures/load_use.png) |
| branch_flush | [PNG](../build/runs/20260914_155026_886660_all_seed1/figures/branch_flush.png) |

本次没有重跑历史的其他种子、pytest、C 语法检查或负向脚本测试。未运行 Verilator lint、综合、FPGA 时序、板级测试、真实 SRAM/MMIO/CNN。stub 仅实现对齐 LW/SW 数据行为；字节/半字类型只验证 Control 译码。同步 IMEM 返回、生产 LSU、CNN 端口及 memory master 均待对应负责人交付后验证。

接口确认与系统验证分开记录：M 已正式接受 C1 v1.0；RESET_PC/全局复位/公共地址/真实存储时序以及 Z 侧协议仍需按 [P1 回复的 S-01～S-10 表](control_reply_to_P1.md) 完成共同冻结。

历史证据保留在 [旧验证报告](../说明文档/原版/docs/verification_report.md)。docs/figures 内仍为有 provenance 标注的历史图，当前报告直接链接本次 run 目录。
