/* 图 CNN Driver Control 的软件示例；不是 CNN RTL 或端到端识别程序。
 * MMIO 基地址由调用者提供，CNN_PARAM 接受负责人预先打包的参数字。
 * 假设无缓存、无重排、无未完成写事务的单核固定时序 LSU。
 * atomic_signal_fence 仅约束编译器，不能替代目标平台 I/O 屏障或 cache flush。
 * W1P/start 和 sticky done/error 仍是待冻结约定；本 Control 不产生这些信号。
 */
#include <stdint.h>
#include <stddef.h>
#include <stdatomic.h>

typedef struct {
    volatile uint32_t CONTROL;
    volatile const uint32_t STATUS;
    volatile uint32_t INPUT_ADDR;
    volatile uint32_t OUTPUT_ADDR;
    volatile uint32_t WEIGHT_ADDR;
    volatile uint32_t BIAS_ADDR;
    volatile uint32_t IMAGE_SIZE;
    volatile uint32_t CHANNELS;
    volatile uint32_t CNN_PARAM;
} cnn_registers;

_Static_assert(offsetof(cnn_registers, STATUS)==0x04, "STATUS offset");
_Static_assert(offsetof(cnn_registers, INPUT_ADDR)==0x08, "INPUT_ADDR offset");
_Static_assert(offsetof(cnn_registers, OUTPUT_ADDR)==0x0c, "OUTPUT_ADDR offset");
_Static_assert(offsetof(cnn_registers, WEIGHT_ADDR)==0x10, "WEIGHT_ADDR offset");
_Static_assert(offsetof(cnn_registers, BIAS_ADDR)==0x14, "BIAS_ADDR offset");
_Static_assert(offsetof(cnn_registers, IMAGE_SIZE)==0x18, "IMAGE_SIZE offset");
_Static_assert(offsetof(cnn_registers, CHANNELS)==0x1c, "CHANNELS offset");
_Static_assert(offsetof(cnn_registers, CNN_PARAM)==0x20, "CNN_PARAM offset");
_Static_assert(sizeof(cnn_registers)==0x24, "exactly nine 32-bit registers");

typedef struct {
    uint32_t input_addr, output_addr, weight_addr, bias_addr;
    uint16_t height, width, input_channels, output_channels;
    uint32_t packed_cnn_param;
} cnn_layer_config;

enum { CNN_OK=0, CNN_BAD_ARGUMENT=-1, CNN_BUSY=-2, CNN_ERROR=-3, CNN_TIMEOUT=-4 };

int cnn_run_layer(uintptr_t mmio_base, const cnn_layer_config *p, uint32_t poll_limit)
{
    if (!p || !poll_limit || (mmio_base & 3u) ||
        ((p->input_addr|p->output_addr|p->weight_addr|p->bias_addr)&3u) ||
        !p->height || !p->width || !p->input_channels || !p->output_channels)
        return CNN_BAD_ARGUMENT;
    cnn_registers *r=(cnn_registers *)mmio_base;
    if (r->STATUS & 1u) return CNN_BUSY;
    r->INPUT_ADDR=p->input_addr;
    r->OUTPUT_ADDR=p->output_addr;
    r->WEIGHT_ADDR=p->weight_addr;
    r->BIAS_ADDR=p->bias_addr;
    r->IMAGE_SIZE=((uint32_t)p->height<<16)|p->width;
    r->CHANNELS=((uint32_t)p->output_channels<<16)|p->input_channels;
    r->CNN_PARAM=p->packed_cnn_param;
    atomic_signal_fence(memory_order_seq_cst);
    r->CONTROL=1u; /* 只写一次：单周期脉冲由 Datapath 寄存器组产生。 */
    atomic_signal_fence(memory_order_seq_cst);
    for (uint32_t n=0;n<poll_limit;++n) {
        uint32_t status=r->STATUS;
        if (status & 4u) return CNN_ERROR;
        if (status & 2u) return CNN_OK;
    }
    return CNN_TIMEOUT;
}

/* 下一层由调用者交换 input_addr/output_addr，再调用 cnn_run_layer。
 * 最后输出的 embedding/分类分数仍由 CPU 软件处理；没有 DB_ADDR/RESULT_ID/SCORE。
 * 不自动发送 soft_reset：发生错误时，恢复策略由系统软件和 CNN 负责人确定。
 */
