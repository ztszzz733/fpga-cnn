# CPU_CONTROL v1.0 / C1 — P1 交付包

日期：2026-09-14。M 侧已正式接受 C1 开发基线，端口/编码/生产 RTL 无改动。

1. 先看 [M 正式回复](docs/control_reply_to_P1.md)：含 D1 回复入口、package 哈希、生产清单和三方待办。
2. 集成使用 rtl/filelists/cpu_control.f 的 7 个文件，路径相对本目录；共享 package 只编译一次。
3. [端口契约](docs/cpu_control_interface.md)、[定向序列与期望](docs/control_datapath_directed_tests.md)、[存储边沿要求](docs/memory_timing_contract.md)。
4. 完整回归：python scripts/run_tests.py --test all --seed 1 --random-cases 1000 --waves --plot。需要本地 Python、scripts/requirements.txt 中依赖及 Icarus 或 Vivado XSim；本次实际使用 XSim 2026.1。
5. [本次结果](docs/verification_report.md)：1,244 场景、30,463 检查、0 失败；生产 7 文件另已单独编译展开。真实 Datapath/CNN 未提供，尚未联调。

所有文件相对路径及 SHA-256 见 HANDOFF_MANIFEST.json。说明文档/原版及历史 build 证据为保留引用，不代表当前确认状态；当前以 docs/control_reply_to_P1.md 和 docs/verification_report.md 为准。日志内记录的原运行绝对路径用于追溯，复现请在解压根目录执行上述命令。
