# CPU source handoff for CNN integration

Date: 2026-10-08

Read [CPU-side interface and delivery guide](docs/CPU侧对CNN接口与代码交付说明.md) first.

- Existing CPU Control, production Datapath and SoC support RTL are copied byte-for-byte.
- CNN algorithm RTL is supplied by the receiver. Place the matching FPGA1/rtl directory at partners/cnn/FPGA1/rtl/.
- Required FPGA1.zip SHA256: 3c3e6b390c8ade24e65a8864db3dc962c92b2411f8391b8cc9ceceaf3b6b016c
- rtl/compat/tensor_operator_engine.sv is the existing isolated XSim syntax-equivalent copy. Do not compile both copies.
- System file list: rtl/filelists/system_cnn.f. Resolve paths from this package root.
- CPU/support-only file list: rtl/filelists/cpu_side.f. Top-level CPU module: cpu_core.
- Board top: face_soc_top. Computational test harness: face_soc_cnn_top.

After adding CNN sources, run from this directory with Python 3 and Vivado XSim available:

```text
python scripts/run_cnn_integration.py
python -m unittest discover -s tb -p test_uart_image_transfer.py
```

scripts/run_tests.py is included unchanged as the helper dependency imported by run_cnn_integration.py. Its standalone Control/stub regression resources are not part of this handoff.

SHA256SUMS.json covers every packaged file except itself. No historical build output, tools, proxy configuration, full CNN source tree or FPGA pin constraints are included.

RTL simulation is not FPGA board validation or full-model accuracy acceptance.
